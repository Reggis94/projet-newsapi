const express = require('express')
const axios = require('axios');
const router = express.Router()

router.route('/').get(function(request, response) {
    response.send('Hello World')
})
/*
Get list of all the news from the USA
*/
router.route('/country-us').get(function(request, response) {
	/*
	const news = [{'title': 1}]
    response.send(news)
	*/
	axios.get('https://newsapi.org/v2/top-headlines?country=us&apiKey=ac9ba4cd8c7c4040be46ee2716ab3508').then((httpresponse) => response.send(httpresponse.data))
	
})
/*
Get list of a specific news
*/
router.route('/news:id').get(function(request, response) {
	const news = [{'title': 1}]
    response.send(news)
})

router.route('/comments').get((request, response) => {
	axios.get('https://jsonplaceholder.typicode.com/comments').then((httpresponse) => response.send(typeof httpresponse.data))
	
})


module.exports = router
