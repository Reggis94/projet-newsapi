# News Feed Project - Back-end

Written by {YOUR_NAMES_OR_LOGINS}

## How to run the project

## Dependencies

Install the missing dependencies with 
> npm install

## Run the server

You can run the server using 
> npm start
