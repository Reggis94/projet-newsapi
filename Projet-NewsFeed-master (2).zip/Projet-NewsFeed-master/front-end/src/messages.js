const messages = [
	{
		author: 'test',
		message: 'Hello'
	}
]