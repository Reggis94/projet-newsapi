/*console.log("App.js Loaded");

import  { messages } from './messages'
console.log(messages)

export {messages}
*/
import axios from 'axios'
const ws = new WebSocket('ws://127.0.0.1:8888')
ws.onmessage = (message) => {
	console.log(message)
	ws.send("wsh");
	alert(message);
}

ws.onopen = () => {
	ws.send("Hi")
	
	ws.onmessage = (message) => {
	console.log(message)
	
	alert(message);
}
}

//On place l'objet de la news à afficher ici
var choosenNews = null;



axios.get('http://localhost:8080/country-us').then((response) => {
	console.log(response);
	var newsUsa = "";
	
	for(var i = 0; i < response.data.articles.length; i++)
	{
		if(response.data.articles[i].author != null && response.data.articles[i].title != null && response.data.articles[i].description != null && response.data.articles[i].urlToImage != null)
		{
			newsUsa = newsUsa + '<div class="col-12 col-md-6 postNews"><!-- Single Blog Post --><div class="single-blog-post"><!-- Post Thumbnail --><div class="post-thumbnail"><img src="'+ response.data.articles[i].urlToImage +'" alt="Image"><!-- Catagory --><div class="post-cta"><a href="#">USA</a></div></div><!-- Post Content --><div class="post-content"><a href="'+ i +'" class="headline"><h5>'+ response.data.articles[i].title +'</h5></a><p>'+ response.data.articles[i].description +'</p><!-- Post Meta --><!--<div class="post-meta"><p>'+ response.data.articles[i].author +'</p>--></div></div></div></div>';
		
		}
		/*
		else{
			//On ne fait rien
			newsUsa = newsUsa + '<div style="display: hidden" class="col-12 col-md-6"><!-- Single Blog Post --><div class="single-blog-post"><!-- Post Thumbnail --><div class="post-thumbnail"><img src="'+ response.data.articles[i].urlToImage +'" alt="Image"><!-- Catagory --><div class="post-cta"><a href="#">USA</a></div></div><!-- Post Content --><div class="post-content"><a href="#" class="headline"><h5>'+ response.data.articles[i].title +'</h5></a><p>'+ response.data.articles[i].description +'</p><!-- Post Meta --><!--<div class="post-meta"><p>'+ response.data.articles[i].author +'</p>--></div></div></div></div>';
		}*/
		
	}
	document.getElementById("country-usa").getElementsByClassName('row')[0].innerHTML = newsUsa;
	var postNewsElements = document.getElementsByClassName("postNews");
	for(var k = 0; k < document.getElementsByClassName("col-12 col-md-6 postNews").length; k++)
	{
		postNewsElements[k].addEventListener("click", showSingleNews(i));
	}
	//document.getElementsByClassName("postNews")[i].addEventListener("click", showSingleNews(i));
	var body = document.getElementsByTagName("body");
	
	function showSingleNews(j) {
		document.getElementById("myModal").innerHTML = '<div class="col-12 col-md-6"><!-- Single Blog Post --><div class="single-blog-post"><!-- Post Thumbnail --><div class="post-thumbnail"><img src="'+ response.data.articles[j].urlToImage +'" alt="Image"><!-- Catagory --><div class="post-cta"><a href="#">USA</a></div></div><!-- Post Content --><div class="post-content"><a href="'+ i +'" class="headline"><h5>'+ response.data.articles[j].title +'</h5></a><p>'+ response.data.articles[j].description +'</p><!-- Post Meta --><!--<div class="post-meta"><p>'+ response.data.articles[j].author +'</p>--></div></div></div></div>';;
	}
	
})

