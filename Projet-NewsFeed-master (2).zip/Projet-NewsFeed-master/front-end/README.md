# News Feed Project - Front-end

Written by {YOUR_NAMES_OR_LOGINS}

## How to run the project

## Dependencies

Install the missing dependencies with 
> npm install

## Run webpack

You can run the webpack watcher using 
> npm start
